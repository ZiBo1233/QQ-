//
//  LeftSlideView.m
//  QQ侧滑模型
//
//  Created by 王一臣 on 15/9/29.
//  Copyright © 2015年 王一臣. All rights reserved.
//

#import "LeftSlideView.h"

//添加手势代理
@interface LeftSlideView ()<UIGestureRecognizerDelegate>
{
    //实时横向位移
    CGFloat _scalef;
}
//背景黑色蒙板
@property (nonatomic,strong) UIView *backView;
//背景信息页面
@property (nonatomic,strong) UIViewController *backMesView;
@end

@implementation LeftSlideView

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}
//添加两个功能页面的抽屉函数
- (instancetype)initWithLeftView:(UIViewController *)leftVC
                     andMainView:(UIViewController *)mainVC
{
    if (self=[super init])
    {
        //滑动速度的设置
        self.speedf=0.7;
        
        //功能页面的添加
        self.leftVC=leftVC;
        self.mainVC=mainVC;
        
        //滑动手势
        self.pan=[[UIPanGestureRecognizer alloc]initWithTarget:self
                                                        action:@selector(panAction:)];
        //主页面添加该手势
        [self.mainVC.view addGestureRecognizer:self.pan];
        
        self.pan.delegate=self;
        
        //隐藏背景页面
        self.leftVC.view.hidden=YES;
        //添加背景页面
        [self.view addSubview:self.leftVC.view];

        //背景模糊黑影图片
        UIView *blackView=[[UIView alloc]init];
        [blackView setFrame:CGRectMake(0, 0, viewWidth,viewHeight)];
        blackView.backgroundColor=[UIColor blackColor];
        blackView.alpha=0.5;
        self.backView=blackView;
        //背景页面添加黑色蒙板
        [self.view addSubview:blackView];
        
        //获取左侧背景Messageview
        self.backMesView=leftVC;
        self.backMesView.view.frame=CGRectMake(0,0,viewWidth-leftDistance,viewHeight);
        //设置左侧背景view的缩放系数
        self.backMesView.view.transform=CGAffineTransformMakeScale(LeftScale,LeftScale);
        //设置左侧背景view的初始位置
        self.backMesView.view.center=CGPointMake(LeftCenterX,viewHeight*0.5);
        
        //容器添加主页
        [self.view addSubview:self.mainVC.view];
        //初始化侧滑关闭窗
        self.closed=YES;
        
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.leftVC.view.hidden=NO;
}

#pragma mark - 滑动手势

//滑动手势
-(void)panAction:(UIPanGestureRecognizer *)rec
{
    //通过translationInView获取移动的点
    CGPoint currentPoint=[rec translationInView:self.view];
    //获取实时横向位移参数(当前手指滑动的x轴位移量 ＊ 滑动速率＋已经积累的横轴移动量)
    _scalef=(currentPoint.x*self.speedf+_scalef);
    
    //判断view是否还需要跟随手指移动手指
    BOOL moveOrNot=YES;
    //判断是否滑动view超出滑动边界，如果超出则关闭滑动权限
    //判断标准：自身滑动的view的左上角x值小于等于0并且横向滑动依旧向左，或者反之，则条件成立
    if ((self.mainVC.view.frame.origin.x<=0 && _scalef<=0)||(self.mainVC.view.frame.origin.x>=viewWidth-leftDistance && _scalef>=0))
    {
        //边界管控
        _scalef=0;
        //关闭可移动属性
        moveOrNot=NO;
    }
    
    //根据判断情况进行左滑或者右滑
    if (moveOrNot && (rec.view.frame.origin.x>=0) && (rec.view.frame.origin.x<=(viewWidth-leftDistance)))
    {
        //获取滑动时屏幕中心点的x值
        CGFloat moveFloatX=(rec.view.center.x+currentPoint.x*self.speedf);
        //获取滑动时屏幕中心点的y值
        CGFloat moveFloatY=rec.view.center.y;
        
        //通过获取在滑动过程中view中心点的x值，判断该值是否越过屏幕中心点，如果越过强制修正。
        //该功能是为了消除连续触控向左滑动时出现超出，从而使右边出现底层页面的情况
        if (moveFloatX<viewWidth*0.5)
        {
            moveFloatX=viewWidth*0.5;
        }
        
        //重新赋值滑动view的中心点
        rec.view.center=CGPointMake(moveFloatX,moveFloatY);
        
        //----------------------缩放部分----------------------
        //获得屏幕按滑动比例缩放的系数
        //原理：整个屏幕缩放的系数是定值，总滑动的距离为屏幕宽度减去右边显示的部分，缩放系数即滑动横向距离除以总滑动距离
        CGFloat mainScaleNum=1-(1-ScaleNumber)*(rec.view.frame.origin.x/(viewWidth-leftDistance));
        //按缩放系数进行缩放
        rec.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,mainScaleNum,mainScaleNum);
        
        NSLog(@"mask=%f\nleft=%f",self.backView.frame.size.height,self.leftVC.view.frame.size.height);
        
        
        //------------------不明------------------
        //重置滑动的参数
        [rec setTranslation:CGPointMake(0,0) inView:self.view];
        
        //左侧背景信息页的中心点x轴设置
        CGFloat leftViewCenterX=LeftCenterX+((viewWidth-leftDistance)*0.5-LeftCenterX)*(rec.view.frame.origin.x)/(viewWidth-leftDistance);
        //左侧背景信息页缩放系数
        CGFloat leftScaleNum=LeftScale+(1-LeftScale)*(rec.view.frame.origin.x)/(viewWidth-leftDistance);
        //背景信息页的中心点重置
        self.backMesView.view.center=CGPointMake(leftViewCenterX,viewHeight*0.5);
        //背景信息页的缩放系数重置
        self.backMesView.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,leftScaleNum,leftScaleNum);
        
        //背景蒙板透明度设置
        CGFloat currentAlpha=LeftAlpha-LeftAlpha*(rec.view.frame.origin.x)/(viewWidth-leftDistance);
        self.backView.alpha=currentAlpha;
        
    }
    //超出滑动范围
    else
    {
        //判断滑动view左边界超出
        if (rec.view.frame.origin.x<0)
        {
            //执行关闭左滑抽屉程序
            [self closeLeftView];
            //滑动横轴参数重置
            _scalef=0;
        }
        //判断滑动view右边界超出
        else if (rec.view.frame.origin.x>(viewWidth-leftDistance))
        {
            //执行开启左滑抽屉程序
            [self openLeftView];
            //滑动横轴参数重置
            _scalef=0;
        }
    }
    
    //手势结束后修正位置,超过约一半时向多出的一半偏移
    if (rec.state==UIGestureRecognizerStateEnded)
    {
        //判断滑动的横向取值是否大于给定的动作变化的赋值范围
        if (fabs(_scalef) > vCouldChangeDeckStateDistance)
        {
            //满足大于条件，判断滑动视图是否关闭，与原状态取反
            if (self.closed)
            {
                [self openLeftView];
            }
            else
            {
                [self closeLeftView];
            }
        }
        else
        {
            //满足小于条件，判断滑动视图是否关闭，保持原状态不变
            if (self.closed)
            {
                [self closeLeftView];
            }
            else
            {
                [self openLeftView];
            }
        }
        //横向滑动值重置
        _scalef=0;
    }
    
}
-(void)closeLeftView
{
    //开始动画
    [UIView beginAnimations:nil context:nil];
    //主页面的比例缩放为原始1.0倍
    self.mainVC.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,1.0,1.0);
    //主页面的中心点重置
    self.mainVC.view.center=CGPointMake(viewWidth/2,viewHeight/2);
    //页面关闭设置为yes
    self.closed=YES;
    
    //背景信息页面的中心点初始化重置
    self.backMesView.view.center=CGPointMake(LeftCenterX,viewHeight*0.5);
    self.backMesView.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,LeftScale,LeftScale);
    //蒙板的模糊度初始化
    self.backView.alpha=LeftAlpha;
    
    //结束动画
    [UIView commitAnimations];
    [self removeSingleTap];
}
-(void)openLeftView
{
    [UIView beginAnimations:nil context:nil];
    self.mainVC.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,ScaleNumber,ScaleNumber);
    self.mainVC.view.center = kMainPageCenter;
    self.closed = NO;
    
    self.backMesView.view.center=CGPointMake((viewWidth-leftDistance)*0.5,viewHeight*0.5);
    self.backMesView.view.transform=CGAffineTransformScale(CGAffineTransformIdentity,1.0,1.0);
    self.backView.alpha=0;
    
    [UIView commitAnimations];
    [self disableTapButton];

}
#pragma mark - 行为收敛控制
- (void)disableTapButton
{
    //遍历主页面所有摁钮，关闭可选控制
    for (UIButton *tempButton in [_mainVC.view subviews])
    {
        [tempButton setUserInteractionEnabled:NO];
    }
    //单击
    if (!self.sideslipTapGes)
    {
        //创建手势，并定义为单击手势
        self.sideslipTapGes=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handeTap:)];
        //控制点击出发时间的点击数
        [self.sideslipTapGes setNumberOfTapsRequired:1];
        //给主页面添加该手势
        [self.mainVC.view addGestureRecognizer:self.sideslipTapGes];
        //点击事件盖住其它响应事件,但盖不住Button;
        self.sideslipTapGes.cancelsTouchesInView = YES;
    }
}
//关闭行为收敛
- (void) removeSingleTap
{
    for (UIButton *tempButton in [self.mainVC.view  subviews])
    {
        [tempButton setUserInteractionEnabled:YES];
    }
    [self.mainVC.view removeGestureRecognizer:self.sideslipTapGes];
    self.sideslipTapGes = nil;
}
#pragma mark - 单击手势
-(void)handeTap:(UITapGestureRecognizer *)tap
{
    
    if ((!self.closed) && (tap.state == UIGestureRecognizerStateEnded))
    {
        [UIView beginAnimations:nil context:nil];
        tap.view.transform = CGAffineTransformScale(CGAffineTransformIdentity,1.0,1.0);
        tap.view.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2,[UIScreen mainScreen].bounds.size.height/2);
        self.closed = YES;
        
        self.leftVC.view.center = CGPointMake(LeftCenterX,viewHeight * 0.5);
        self.leftVC.view.transform = CGAffineTransformScale(CGAffineTransformIdentity,LeftScale,LeftScale);
        self.backView.alpha = LeftAlpha;
        
        [UIView commitAnimations];
        _scalef = 0;
        [self removeSingleTap];
    }
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
