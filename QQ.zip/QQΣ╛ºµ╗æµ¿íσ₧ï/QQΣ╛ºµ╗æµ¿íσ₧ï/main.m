//
//  main.m
//  QQ侧滑模型
//
//  Created by 马海天 on 15/9/29.
//  Copyright © 2015年 王一臣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
