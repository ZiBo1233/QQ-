//
//  mainViewView.m
//  QQ侧滑模型
//
//  Created by 王一臣 on 15/9/29.
//  Copyright © 2015年 王一臣. All rights reserved.
//

#import "mainViewView.h"
#define screenWidth [[UIScreen mainScreen] bounds].size.width
#define screenHeight [[UIScreen mainScreen] bounds].size.height

@interface mainViewView ()

@end

@implementation mainViewView

@synthesize mainScroll;
-(void)viewDidAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //背景图片
    UIImageView *titleImage=[[UIImageView alloc]initWithFrame:CGRectMake(0,0, screenWidth,screenHeight/4)];
    UIImage *backImage=[UIImage imageNamed:@"testpic.jpg"];
    [titleImage setImage:backImage];
    [self.view addSubview:titleImage];
    
    //摁钮滑动的重新定义
    [mainScroll setContentSize:CGSizeMake(screenWidth,screenWidth*5/3)];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
