//
//  LeftSlideView.h
//  QQ侧滑模型
//
//  Created by 王一臣 on 15/9/29.
//  Copyright © 2015年 王一臣. All rights reserved.
//

#import <UIKit/UIKit.h>

#define viewWidth        [[UIScreen mainScreen] bounds].size.width
#define viewHeight       [[UIScreen mainScreen] bounds].size.height
//开启左抽屉时露出的部分
#define leftDistance     100
//打开左侧窗时，中视图(右视图）缩放比例
#define ScaleNumber   0.8
//左侧初始缩放比例
#define LeftScale    0.7
//左侧初始偏移量
#define LeftCenterX 30
//左侧蒙版的最大值
#define LeftAlpha 0.9
//滑动距离大于此数时，状态改变（关--》开，或者开--》关）
#define vCouldChangeDeckStateDistance  (viewWidth - leftDistance) / 2.0 - 40
//打开左侧窗时，中视图中心点
#define kMainPageCenter  CGPointMake(viewWidth + viewWidth * ScaleNumber / 2.0 - leftDistance, viewHeight / 2)

@interface LeftSlideView : UIViewController

//主窗控制器
@property (nonatomic,strong) UIViewController *mainVC;
//背景窗控制器
@property (nonatomic, strong) UIViewController *leftVC;
//滑动速度系数-建议在0.5-1之间。默认为0.5
@property (nonatomic, assign) CGFloat speedf;
//滑动手势控制器
@property (nonatomic, strong) UIPanGestureRecognizer *pan;
//点击手势控制器，是否允许点击视图恢复视图位置。默认为yes
@property (nonatomic, strong) UITapGestureRecognizer *sideslipTapGes;
//侧滑窗是否关闭(关闭时显示为主页)
@property (nonatomic, assign) BOOL closed;

/**
 @brief 初始化侧滑控制器
 @param leftVC 右视图控制器
 mainVC 中间视图控制器
 @result instancetype 初始化生成的对象
 */
- (instancetype)initWithLeftView:(UIViewController *)leftVC
                     andMainView:(UIViewController *)mainVC;

@end
